# JUnit test cases for SpotBugs Eclipse Plugin

This file hosts JUnit test cases which does not need Eclipse to run.
Travis CI will run test in this project automatically.

We have another project `eclipsePlugin-test`, to test SpotBugs Eclipse Plugin with Eclipse.
Ideally we should migrate this `eclipsePlugin-junit` project to that.
