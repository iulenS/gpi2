/*
 * FindBugs - Find Bugs in Java programs
 * Copyright (C) 2006, University of Maryland
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston MA 02111-1307, USA
 */

package edu.umd.cs.findbugs.gui2;

import java.sql.Timestamp;
import java.util.Arrays;
import java.util.Collection;
import java.util.Comparator;

import edu.umd.cs.findbugs.AppVersion;
import edu.umd.cs.findbugs.BugCollection;
import edu.umd.cs.findbugs.BugInstance;
import edu.umd.cs.findbugs.BugPattern;
import edu.umd.cs.findbugs.BugRanker;
import edu.umd.cs.findbugs.I18N;
import edu.umd.cs.findbugs.Priorities;
import edu.umd.cs.findbugs.ProjectPackagePrefixes;
import edu.umd.cs.findbugs.util.ClassName;

/**
 * A useful enum for dealing with all the types of filterable and sortable data
 * in BugInstances This is the preferred way for getting the information out of
 * a BugInstance and formatting it for display It also has the comparators for
 * the different types of data
 *
 * @author Reuven
 */

public enum Sortables implements Comparator<String> {

    FIRSTVERSION(edu.umd.cs.findbugs.L10N.getLocalString("sort.first_version", "First Version")) {
        @Override
        public String getFrom(BugInstance bug) {
            return Long.toString(bug.getFirstVersion());
        }

        @Override
        public String formatValue(String value) {
            int seqNum = Integer.parseInt(value);
            BugCollection bugCollection = MainFrame.getInstance().getBugCollection();
            if (bugCollection == null) {
                return "--";
            }
            AppVersion appVersion = bugCollection.getAppVersionFromSequenceNumber(seqNum);
            if (appVersion != null) {
                String timestamp = new Timestamp(appVersion.getTimestamp()).toString();
                return appVersion.getReleaseName() + " (" + timestamp.substring(0, timestamp.indexOf(' ')) + ")";
            } else {
                return "#" + seqNum;
            }
        }

        @Override
        public int compare(String one, String two) {
            // Numerical (zero is first)
            return Integer.valueOf(one).compareTo(Integer.valueOf(two));
        }

        @Override
        public boolean isAvailable(MainFrame mainframe) {
            BugCollection bugCollection = mainframe.getBugCollection();
            if (bugCollection == null) {
                return true;
            }
            long sequenceNumber = bugCollection.getCurrentAppVersion().getSequenceNumber();
            return sequenceNumber > 0;

        }
    },

    LASTVERSION(edu.umd.cs.findbugs.L10N.getLocalString("sort.last_version", "Last Version")) {
        @Override
        public String getFrom(BugInstance bug) {
            return Long.toString(bug.getLastVersion());
        }

        @Override
        public String formatValue(String value) {
            // System.out.println("Formatting last version value");
            if ("-1".equals(value)) {
                return "";
            }
            int seqNum = Integer.parseInt(value);
            BugCollection bugCollection = MainFrame.getInstance().getBugCollection();
            if (bugCollection == null) {
                return "--";
            }
            AppVersion appVersion = bugCollection.getAppVersionFromSequenceNumber(seqNum);
            if (appVersion != null) {
                String timestamp = new Timestamp(appVersion.getTimestamp()).toString();
                return appVersion.getReleaseName() + " (" + timestamp.substring(0, timestamp.indexOf(' ')) + ")";
            } else {
                return "#" + seqNum;
            }
        }

        @Override
        public int compare(String one, String two) {
            if (one.equals(two)) {
                return 0;
            }

            // Numerical (except that -1 is last)
            int first = Integer.parseInt(one);
            int second = Integer.parseInt(two);
            if (first == second) {
                return 0;
            }
            if (first < 0) {
                return 1;
            }
            if (second < 0) {
                return -1;
            }
            if (first < second) {
                return -1;
            }
            return 1;
        }

        @Override
        public boolean isAvailable(MainFrame mainframe) {
            BugCollection bugCollection = mainframe.getBugCollection();
            if (bugCollection == null) {
                return true;
            }
            return bugCollection.getCurrentAppVersion().getSequenceNumber() > 0;

        }

    },

    PRIORITY(edu.umd.cs.findbugs.L10N.getLocalString("sort.priority", "Confidence")) {
        @Override
        public String getFrom(BugInstance bug) {
            return String.valueOf(bug.getPriority());
        }

        @Override
        public String formatValue(String value) {
            if (value.equals(String.valueOf(Priorities.HIGH_PRIORITY))) {
                return edu.umd.cs.findbugs.L10N.getLocalString("sort.priority_high", "High");
            }
            if (value.equals(String.valueOf(Priorities.NORMAL_PRIORITY))) {
                return edu.umd.cs.findbugs.L10N.getLocalString("sort.priority_normal", "Normal");
            }
            if (value.equals(String.valueOf(Priorities.LOW_PRIORITY))) {
                return edu.umd.cs.findbugs.L10N.getLocalString("sort.priority_low", "Low");
            }
            if (value.equals(String.valueOf(Priorities.EXP_PRIORITY))) {
                return edu.umd.cs.findbugs.L10N.getLocalString("sort.priority_experimental", "Experimental");
            }
            return edu.umd.cs.findbugs.L10N.getLocalString("sort.priority_ignore", "Ignore"); // This
            // probably
            // shouldn't
            // ever
            // happen,
            // but
            // what
            // the
            // hell,
            // let's
            // be
            // complete

        }

        @Override
        public int compare(String one, String two) {
            // Numerical
            return Integer.valueOf(one).compareTo(Integer.valueOf(two));
        }
    },
    CLASS(edu.umd.cs.findbugs.L10N.getLocalString("sort.class", "Class")) {
        @Override
        public String getFrom(BugInstance bug) {
            return bug.getPrimarySourceLineAnnotation().getClassName();
        }

        @Override
        public int compare(String one, String two) {
            // If both have dollar signs and are of the same outer class,
            // compare the numbers after the dollar signs.
            try {
                if (one.contains("$") && two.contains("$")
                        && one.substring(0, one.lastIndexOf('$')).equals(two.substring(0, two.lastIndexOf('$')))) {
                    return Integer.valueOf(one.substring(one.lastIndexOf('$'))).compareTo(
                            Integer.valueOf(two.substring(two.lastIndexOf('$'))));
                }
            } catch (NumberFormatException e) {
            } // Somebody's playing silly buggers with dollar signs, just do it
              // lexicographically

            // Otherwise, lexicographicalify it
            return one.compareTo(two);
        }
    },
    PACKAGE(edu.umd.cs.findbugs.L10N.getLocalString("sort.package", "Package")) {
        @Override
        public String getFrom(BugInstance bug) {
            return bug.getPrimarySourceLineAnnotation().getPackageName();
        }

        @Override
        public String formatValue(String value) {
            if ("".equals(value)) {
                return "(Default)";
            }
            return value;
        }
    },
    PACKAGE_PREFIX(edu.umd.cs.findbugs.L10N.getLocalString("sort.package_prefix", "Package prefix")) {
        @Override
        public String getFrom(BugInstance bug) {
            int count = GUISaveState.getInstance().getPackagePrefixSegments();

            if (count < 1) {
                count = 1;
            }
            String packageName = bug.getPrimarySourceLineAnnotation().getPackageName();
            return ClassName.extractPackagePrefix(packageName, count);
        }

        @Override
        public String formatValue(String value) {
            return value + "...";
        }
    },
    CATEGORY(edu.umd.cs.findbugs.L10N.getLocalString("sort.category", "Category")) {
        @Override
        public String getFrom(BugInstance bug) {

            BugPattern bugPattern = bug.getBugPattern();
            return bugPattern.getCategory();
        }

        @Override
        public String formatValue(String value) {
            return I18N.instance().getBugCategoryDescription(value);
        }

        @Override
        public int compare(String one, String two) {
            String catOne = one;
            String catTwo = two;
            int compare = catOne.compareTo(catTwo);
            if (compare == 0) {
                return 0;
            }
            if ("CORRECTNESS".equals(catOne)) {
                return -1;
            }
            if ("CORRECTNESS".equals(catTwo)) {
                return 1;
            }
            return compare;

        }

    },
    BUGCODE(edu.umd.cs.findbugs.L10N.getLocalString("sort.bug_kind", "Bug Kind")) {
        @Override
        public String getFrom(BugInstance bug) {
            BugPattern bugPattern = bug.getBugPattern();
            return bugPattern.getAbbrev();
        }

        @Override
        public String formatValue(String value) {
            return I18N.instance().getBugTypeDescription(value);
        }

        @Override
        public int compare(String one, String two) {
            return formatValue(one).compareTo(formatValue(two));
        }
    },
    TYPE(edu.umd.cs.findbugs.L10N.getLocalString("sort.bug_pattern", "Bug Pattern")) {
        @Override
        public String getFrom(BugInstance bug) {
            return bug.getBugPattern().getType();
        }

        @Override
        public String formatValue(String value) {
            return I18N.instance().getShortMessageWithoutCode(value);
        }
    },

    BUG_RANK(edu.umd.cs.findbugs.L10N.getLocalString("sort.bug_bugrank", "Bug Rank")) {
        String[] values;
        {
            values = new String[40];
            for (int i = 0; i < values.length; i++) {
                values[i] = String.format("%2d", i);
            }
        }

        @Override
        public String getFrom(BugInstance bug) {
            int rank = BugRanker.findRank(bug);
            return values[rank];
        }

        @Override
        public String formatValue(String value) {
            return value;
        }
    },

    PROJECT(edu.umd.cs.findbugs.L10N.getLocalString("sort.bug_project", "Project")) {

        @Override
        public String getFrom(BugInstance bug) {
            ProjectPackagePrefixes p = MainFrame.getInstance().getProjectPackagePrefixes();
            Collection<String> projects = p.getProjects(bug.getPrimaryClass().getClassName());
            if (projects.size() == 0) {
                return "unclassified";
            }
            String result = projects.toString();

            return result.substring(1, result.length() - 1);
        }

        @Override
        public boolean isAvailable(MainFrame mf) {
            return mf.getProjectPackagePrefixes().size() > 0;
        }

    },

    DIVIDER(" ") {
        @Override
        public String getFrom(BugInstance bug) {
            throw new UnsupportedOperationException();
        }

        @Override
        public String[] getAll() {
            throw new UnsupportedOperationException();
        }

        @Override
        public String formatValue(String value) {
            throw new UnsupportedOperationException();
        }

        @Override
        public int compare(String one, String two) {
            throw new UnsupportedOperationException();
        }
    };

    String prettyName;

    Sortables(String prettyName) {
        this.prettyName = prettyName;
        this.bugLeafNodeComparator = (one, two) -> Sortables.this.compare(Sortables.this.getFrom(one.getBug()), Sortables.this.getFrom(two.getBug()));
    }

    @Override
    public String toString() {
        return prettyName;
    }

    public abstract String getFrom(BugInstance bug);

    public String[] getAll() {
        return getAll(BugSet.getMainBugSet());
    }

    public String[] getAll(BugSet set) {
        return set.getAll(this);
    }

    public String formatValue(String value) {
        return value;
    }

    @Override
    public int compare(String one, String two) {
        // Lexicographical by default
        return one.compareTo(two);
    }

    public String[] getAllSorted() {
        return getAllSorted(BugSet.getMainBugSet());
    }

    public String[] getAllSorted(BugSet set) {
        String[] values = getAll(set);
        Arrays.sort(values, this);
        return values;
    }

    private final SortableStringComparator comparator = new SortableStringComparator(this);

    public SortableStringComparator getComparator() {
        return comparator;
    }

    final Comparator<BugLeafNode> bugLeafNodeComparator;

    public Comparator<BugLeafNode> getBugLeafNodeComparator() {
        return bugLeafNodeComparator;
    }

    public boolean isAvailable(MainFrame frame) {
        return true;
    }

    public static Sortables getSortableByPrettyName(String name) {
        for (Sortables s : values()) {
            if (s.prettyName.equals(name)) {
                return s;
            }
        }
        return null;
    }
}
