JNLP files in this directory is deprecated and not maintained. It will be removed in future release.
