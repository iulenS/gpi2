Bug descriptions
================

This document lists the standard bug patterns reported by SpotBugs.

.. include:: generated/bugDescriptionList.inc
