This directory stores generated files. For detail about generation process, check `/docs/build.sh`
