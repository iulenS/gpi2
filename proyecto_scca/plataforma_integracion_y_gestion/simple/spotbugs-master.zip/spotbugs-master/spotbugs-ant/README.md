# SpotBugs Ant Task

[![Maven Central](https://maven-badges.herokuapp.com/maven-central/com.github.spotbugs/spotbugs-ant/badge.svg)](https://maven-badges.herokuapp.com/maven-central/com.github.spotbugs/spotbugs-ant)
[![Javadocs](http://javadoc.io/badge/com.github.spotbugs/spotbugs-ant.svg)](http://javadoc.io/doc/com.github.spotbugs/spotbugs-ant)
