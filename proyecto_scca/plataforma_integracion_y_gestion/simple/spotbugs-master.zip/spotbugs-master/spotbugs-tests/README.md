# SpotBugs JUnit Tests

[![Maven Central](https://maven-badges.herokuapp.com/maven-central/com.github.spotbugs/spotbugs-tests/badge.svg)](https://maven-badges.herokuapp.com/maven-central/com.github.spotbugs/spotbugs-tests)
