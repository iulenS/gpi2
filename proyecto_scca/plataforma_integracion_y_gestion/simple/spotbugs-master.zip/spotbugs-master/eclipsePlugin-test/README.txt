The source for this projects is licensed under the LGPL v 2.1
that can be found in the file LICENSE.txt

The class JavaProjectHelper is copied from different versions of the same class
found in the JDT project. It is licensed under the Eclipse Public License v1.0,
that can be found at: http://www.eclipse.org/legal/epl-v10.html


## About difference with this project and eclipsePlugin-junit project

Currently tests in this project cannot run in Travis CI build.
If you want to add JUnit test which can run without Eclipse, add test case to eclipsePlugin-junit project.
