public class MakeFieldFinalResolutionExample {
    public static Integer MAGIC_NUMBER = Integer.valueOf(0);

    public static Integer getMagicNumber() {
        return MAGIC_NUMBER;
    }
}
