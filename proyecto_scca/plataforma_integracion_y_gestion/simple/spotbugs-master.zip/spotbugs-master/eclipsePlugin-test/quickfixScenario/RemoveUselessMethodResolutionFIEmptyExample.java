public class RemoveUselessMethodResolutionFIEmptyExample {
    @Override
    protected void finalize() throws Throwable {
    }
}
