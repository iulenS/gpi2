public class MakeInnerTypeStaticResolutionExample {
    static class InnerType {
    }
}
