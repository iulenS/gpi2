# SpotBugs Eclipse Plugin

[![Maven Central](https://maven-badges.herokuapp.com/maven-central/com.github.spotbugs/eclipsePlugin/badge.svg)](https://maven-badges.herokuapp.com/maven-central/com.github.spotbugs/eclipsePlugin)
